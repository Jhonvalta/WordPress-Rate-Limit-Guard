=== Rate Limit Guard ===
Contributors: costresser
Donate link: https://ip-stresser.co/
Tags: brute-force,ddos,security,firewall,ip-stresser
Requires at least: 4.0.1
Tested up to: 6.4.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Rate limit control with a simple click.

== Description ==

This plugin allows you to have a simple rate limit option to protect the site against DDoS or brute force attacks.





== Installation ==

1. Just Active it.
2. Done :)


== Changelog ==

= 1.0 =
* no change.
